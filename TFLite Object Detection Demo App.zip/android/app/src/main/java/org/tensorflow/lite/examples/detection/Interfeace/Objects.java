package org.tensorflow.lite.examples.detection.Interfeace;

public interface Objects {
    public void GetObjectstitle(String hello);
}
