package org.tensorflow.lite.examples.detection.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.tensorflow.lite.examples.detection.R;

import java.util.List;

public class RecyclerviewAdapter extends RecyclerView.Adapter<RecyclerviewAdapter.objectslistholder> {

    private final LayoutInflater mInflater;
//    private final List<Detector.Recognition> mappedRecognition;
    private final List<String> objects_detected;

    public RecyclerviewAdapter(Context context, List<String> objects_detected) {
        this.mInflater = LayoutInflater.from(context);
//        this.mappedRecognition = mappedRecognitions;

        this.objects_detected = objects_detected;
    }

    @NonNull
    @Override
    public objectslistholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.objectslistholder, parent, false);
        return new objectslistholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull objectslistholder holder, int position) {
//    Detector.Recognition items =mappedRecognition.get(position);
        String items=objects_detected.get(position);
//     TextView name=holder.objectname;
 holder.objectname.setText(items);


    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class objectslistholder extends RecyclerView.ViewHolder {
        TextView objectname;

        public objectslistholder(@NonNull View itemView) {
            super(itemView);
            objectname=itemView.findViewById(R.id.object1);

        }
    }
}
